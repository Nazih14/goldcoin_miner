<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Web Company Profile">
  <meta name="author" content="Muhammad Nazih, S.Kom">

  <title> Goldgainer | PT International Development </title>
  <link rel="icon" href="<?php echo base_url();?>media/images/ico/logo.png" type="icon">
  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url();?>media/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-css">
  <!-- Icons And Animation -->
  <link href="<?php echo base_url();?>media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>media/css/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/css/all.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/brands.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/solid.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/ti-icons@0.1.2/css/themify-icons.css" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link href="<?php echo base_url();?>media/css/custom.css" rel="stylesheet" type="text/css">
  
  
  <!-- Core JavaScript Files -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery-3.2.1.slim.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/all.js"></script>
  <!-- Core JavaScript Plugin -->
  <script src="<?php echo base_url();?>media/js/owl.carousel.js"></script>
  <!-- Custom Theme JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/wow.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/custom.js"></script>
  
  <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed|Fugaz+One&display=swap|Roboto" rel="stylesheet">
  
</head>
<body>  

  <nav class="navbar top-nav fixed-top navbar-expand-lg navbar-white bg-white shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="index.html">Goldgainer.com</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"><img src="https://img.icons8.com/color/48/000000/xbox-menu.png"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <ul class="navbar-nav m-auto text-sm-center text-md-center">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/about';?>">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/gallery';?>">Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/event';?>">Event</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/faq';?>">FAQ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/login';?>"><i class="fas fa-lock"></i> Login</a>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav ml-auto search-box">
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-facebook text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-instagram text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-youtube text-white"></i></a>
      </li>
    </ul>
  </div>
</nav>


<!-- <section id="home" class="intro intro-bg bg-overlay parallax"> -->

 <section id="home" class="intro intro-bg parallax">
  <div class="container mt-5">
    <div class="col-12">
      <div class="row">
        <div class="col-lg-12 col-sm-12 caption-two-panel mb-5">
          <div class="intro-caption mt-5">
            <center>
              <h1 class="text-white mb-2">Penyedia Hashpower Terbaik di dunia</h1>
              <p class="text-white mb-4">
               Caranya sangat mudah - mesin penambangan Anda telah selesai dan siap bekerja.
             Segera setelah Anda membuat akun, Anda bisa mulai menambang koin pertama Anda menggunakan layanan penambangan Bitcoin kami yang berbasis cloud!</p>
             <a href="signup.html" class="btn btn-warning text-white"><i class="fas fa-play"></i> Tonton Videonya <span class="fas fa-chevron-circle-right"></span></a>
             <a href="register.html" class="btn btn-outline-warning text-white">COBA SEKARANG <span class="fas fa-chevron-circle-right"></span></a>
           </center>
         </div>
       </div>
     </div>
   </div>
 </section>


 <section class="section"> 
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <center>
          <h2 class="text-dark mt-5"><b>About Us</b></h2>
        </center>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="job-detail mt-2 p-4">
          <div class="job-detail-desc">
            <p class="text-muted f-14 mb-3">Kisah Genesis Mining dimulai pada akhir tahun 2013. Para pendiri kami berkenalan satu sama lain dengan menggunakan platform yang sama untuk membeli dan menjual Bitcoin. Mereka merasa kagum dengan teknologi tersebut dan ingin membangun ladang mereka sendiri, tapi ternyata semua teman mereka juga ingin ikut membangunnya.</p>

            <p class="text-muted f-14 mb-0">Mereka mencetuskan ide penambangan sebagai sebuah layanan dan membangun ladang pertambangan pertama di Eropa Timur. Sejak kami didirikan, kami telah berkembang dengan luar biasa dan banyak hal telah terjadi, tapi satu hal tetap konstan: Kami adalah orang-orang yang sangat percaya akan masa depan mata uang digital dan kami senang menjadi bagian dari komunitas yang berkembang ini.</p>
          </div>
          <hr>
          <ul class="list-inline mt-3 mb-0">
            <li class="list-inline-item mr-3">
              <a href="" class="text-muted f-15 mb-0"><i class="mdi mdi-map-marker mr-2"></i>3659 Turkey Pen Road Manhattan, NY 10016</a>
            </li>

            <li class="list-inline-item mr-3">
              <a href="" class="text-muted f-15 mb-0"><i class="mdi mdi-web mr-2"></i>Www.webthemes.co.in</a>
            </li>

            <li class="list-inline-item mr-3">
              <a href="" class="text-muted f-15 mb-0"><i class="mdi mdi-email mr-2"></i>Webthemes.ltd@gmail.com</a>
            </li>

            <li class="list-inline-item mr-3">
              <a href="" class="text-muted f-15 mb-0"><i class="mdi mdi-cellphone-iphone mr-2"></i>123 456 7890</a>
            </li>
          </ul>
        </div>
      </div>
    </div>


    <br>

    <div class="row">
      <div class="col-lg-12">
        <center>
          <h2 class="text-dark"><b>Experience</b></h2>
        </center>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="job-detail job-list-box mt-4 p-4">
          <div class="row">
            <div class="col-lg-3">
              <div class="company-brand-logo text-center mb-4">
                <img src="images/featured-job/img-2.png" alt="" class="img-fluid mx-auto d-block">
              </div>
            </div>

            <div class="col-lg-9">
              <div class="job-list-desc candidates-profile-exp-desc">
                <h5 class="f-19 mb-2"><a href="#" class="text-dark">Web Themes Pvt.Ltd</a></h5>
                <p class="text-muted mb-0 f-16">PHP Developer</p>
                <p class="text-muted mb-0 f-16">Jan 2016 - Dec 2017</p>
                <p class="text-muted mb-0 f-16">Salary : $950</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-bank mr-2"></i>www.webthemesltd.co.in</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-map-marker mr-2"></i>1919 Ward Road West Nyack, NY 10994</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="job-detail job-list-box mt-4 p-4">
          <div class="row">
            <div class="col-lg-3">
              <div class="company-brand-logo text-center mb-4">
                <img src="images/featured-job/img-3.png" alt="" class="img-fluid mx-auto d-block">
              </div>
            </div>

            <div class="col-lg-9">
              <div class="job-list-desc candidates-profile-exp-desc">
                <h5 class="f-19 mb-2"><a href="#" class="text-dark">Web code Pvt.Ltd</a></h5>
                <p class="text-muted mb-0 f-16">Web Developer</p>
                <p class="text-muted mb-0 f-16">Fab 2015 - July 2018</p>
                <p class="text-muted mb-0 f-16">Salary : $1100</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-bank mr-2"></i>www.webcodeltd.co.in</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-map-marker mr-2"></i>519 Leo Street Butler, PA 16001</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="job-detail job-list-box mt-4 p-4">
          <div class="row">
            <div class="col-lg-3">
              <div class="company-brand-logo text-center mb-4">
                <img src="images/featured-job/img-5.png" alt="" class="img-fluid mx-auto d-block">
              </div>
            </div>

            <div class="col-lg-9">
              <div class="job-list-desc candidates-profile-exp-desc">
                <h5 class="f-19 mb-2"><a href="#" class="text-dark">Brand Themes Pvt.Ltd</a></h5>
                <p class="text-muted mb-0 f-16">PHP Developer</p>
                <p class="text-muted mb-0 f-16">Jan 2016 - Dec 2017</p>
                <p class="text-muted mb-0 f-16">Salary : $1000</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-bank mr-2"></i>www.brandthemesltd.co.in</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-map-marker mr-2"></i>519 Leo Street Butler, PA 16001</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="job-detail job-list-box mt-4 p-4">
          <div class="row">
            <div class="col-lg-3">
              <div class="company-brand-logo text-center mb-4">
                <img src="images/featured-job/img-7.png" alt="" class="img-fluid mx-auto d-block">
              </div>
            </div>

            <div class="col-lg-9">
              <div class="job-list-desc candidates-profile-exp-desc">
                <h5 class="f-19 mb-2"><a href="#" class="text-dark">Small Themes Pvt.Ltd</a></h5>
                <p class="text-muted mb-0 f-16">PHP Developer</p>
                <p class="text-muted mb-0 f-16">Jan 2016 - Dec 2017</p>
                <p class="text-muted mb-0 f-16">Salary : $900</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-bank mr-2"></i>www.smallthemesltd.co.in</p>
                <p class="text-muted mb-0 f-16"><i class="mdi mdi-map-marker mr-2"></i>519 Leo Street Butler, PA 16001</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section>
 <div class="container">
  <div class="row align-items-center mt-5">
   <div class="col-lg-12">
    <center>
      <h1 class="title"><b>What</b> <span class="text-warning"><b>Service</b></span> We
       Offer
     </h1>
     <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut optio velit inventore, expedita quo laboriosam possimus ea consequatur vitae, doloribus consequuntur ex. Nemo assumenda laborum vel, labore ut velit dignissimos.</p>
     <a class="btn btn-warning btn-lg mb-5 text-white" href="#">More Info </a>
   </center>
 </div>
 <div class="col-lg-12">
  <div class="row card-items pt-50">
   <div class="col-lg-4 col-sm-6">
    <div class="card">
     <div class="card-body">
      <center>
        <img src="https://img.icons8.com/bubbles/100/000000/cash-register.png"/>
      </center>
      <h5 class="card-title text-center"><b>Perangkat keras Andasudah berjalan</b></h5>
      <p class="card-text text-center">Tidak perlu repot lagi merakit perangkat mining yang panas serta berisik di rumah Anda. Kami memiliki perangkat mining bitcoin tercepat yang siap bekerja untuk Anda sepenuhnya.</p>
    </div>
  </div>
</div>
<div class="col-lg-4 col-sm-6">
  <div class="card">
   <div class="card-body">
    <center>
      <img class="img-fluid" src="https://img.icons8.com/bubbles/100/000000/design.png"/>
    </center>
    <h5 class="card-title text-center"><b>Tambang mata uang virtual alternatif</b></h5>
    <p class="card-text text-center">Anda dapat menambang mata uang virtual yang tersedia di katalog kami. Alihkan kekuatan mining Anda dengan cepat untuk semua koin menggunakan situs web mining bitcoin kami.</p>
  </div>
</div>
</div>
<div class="col-lg-4 col-sm-6">
  <div class="card">
   <div class="card-body">
    <center>
      <img class="img-fluid" src="https://img.icons8.com/bubbles/100/000000/rescan-document.png"/>
    </center>
    <h5 class="card-title text-center"><b>Dapatkan hasil penambanganpertama Anda hari ini</b></h5>
    <p class="card-text text-center">Anda akan mendapatkan hasil penambangan secara berkala ke dompet yang Anda pilih. Coba platform penambangan Bitcoin kami sekarang!</p>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>


<section class="deneb_cta mt-5">
  <div class="container">
    <div class="cta_wrapper">
      <div class="row align-items-center">
        <div class="col-lg-7">
          <div class="cta_content">
            <h3>Goldgainer dibentuk oleh para profesional bagi para individu yang ingin terlibat dalam penambangan uang kripto</h3>
            <p>Kami percaya bahwa setiap orang harus mendapatkan keuntungan dari pertambangan dan dapat memiliki akses teknologi terbaru dan pusat data industri skala besar dari laptop atau ponsel.</p>
          </div>
        </div>
        <div class="col-lg-5">
          <div class="button_box">
            <a href="#" class="btn btn-warning">Bergabunglah Bersama kami <span class="fas fa-arrow-right"></span></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>




<footer class="deneb_footer">
  <div class="widget_wrapper shadow-sm" style="background-color: #fff;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-12">
          <div class="widget widegt_about">
            <div class="widget_title">
              <img src="assets/images/logo_1.png" class="img-fluid" alt="">
            </div>
            <div class="mb-3">
              <div class="btn btn-primary">SIgn Up</div>
              <div class="btn btn-warning">Sign In</div>
            </div>

            <p>Kami sangat terbuka untuk kemitraan untuk semua perusahaan tambang yang memenuhi persyaratan kami. Jika anda tertarik untuk menjual kapasitas hosting untuk pertambangan melalui platform Goldgainer.com, <br/><a href="">silahkan hubungi kami.</a></p>

            <ul class="social mt-3">
              <li><a href="#"><i class="fab fa-facebook-f" style="margin-top: 7px;"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter" style="margin-top: 7px;"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram" style="margin-top: 7px;"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="widget widget_link">
            <div class="widget_title">
              <h4>Links</h4>
            </div>
            <ul>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">Portfolio</a></li>
              <li><a href="#">Blog</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="widget widget_contact">
            <div class="widget_title">
              <h4>Contact Us</h4>
            </div>
            <div class="contact_info">
              <div class="single_info">
                <div class="icon">
                  <i class="fas fa-phone" style="margin-top: 8px;"></i>
                </div>
                <div class="info">
                  <p><a href="tel:+919246147999">1800-121-3637</a></p>
                  <p><a href="tel:+919246147999">+91 924-614-7999</a></p>
                </div>
              </div>
              <div class="single_info">
                <div class="icon">
                  <i class="fas fa-envelope" style="margin-top: 8px;"></i>
                </div>
                <div class="info">
                  <p><a href="mailto:info@deneb.com">info@deneb.com</a></p>
                  <p><a href="mailto:services@deneb.com">services@deneb.com</a></p>
                </div>
              </div>
              <div class="single_info">
                <div class="icon">
                  <i class="fas fa-map-marker-alt" style="margin-top: 8px;"></i>
                </div>
                <div class="info">
                  <p>125, Park street aven, Brocklyn,<span>Newyork.</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright_area">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="copyright_text">
            <p>Copyright &copy; 2021 All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>


</body>
</html>


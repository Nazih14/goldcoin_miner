<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Web Company Profile">
  <meta name="author" content="Muhammad Nazih, S.Kom">

  <title> Goldgainer | PT International Development </title>
  <link rel="icon" href="<?php echo base_url();?>media/images/ico/logo.png" type="icon">
  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url();?>media/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-css">
  <!-- Icons And Animation -->
  <link href="<?php echo base_url();?>media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>media/css/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/css/all.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/brands.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/solid.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/ti-icons@0.1.2/css/themify-icons.css" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link href="<?php echo base_url();?>media/css/custom.css" rel="stylesheet" type="text/css">
  
  
  <!-- Core JavaScript Files -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery-3.2.1.slim.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/all.js"></script>
  <!-- Core JavaScript Plugin -->
  <script src="<?php echo base_url();?>media/js/owl.carousel.js"></script>
  <!-- Custom Theme JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/wow.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/custom.js"></script>
  
  <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed|Fugaz+One&display=swap|Roboto" rel="stylesheet">
  
</head>
<body>  

  <nav class="navbar top-nav fixed-top navbar-expand-lg navbar-white bg-white shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="index.html">Goldgainer.com</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"><img src="https://img.icons8.com/color/48/000000/xbox-menu.png"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav m-auto text-sm-center text-md-center">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/about';?>">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/gallery';?>">Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/event';?>">Event</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/faq';?>">FAQ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/login';?>"><i class="fas fa-lock"></i> Login</a>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav ml-auto search-box">
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-facebook text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-instagram text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-youtube text-white"></i></a>
      </li>
    </ul>
  </div>
</nav>



<br>
<div class="blog-single mt-5">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-lg-8 m-15px-tb">
                <article class="article">
                    <div class="article-img">
                        <img src="https://via.placeholder.com/800x350/87CEFA/000000" title="" alt="">
                    </div>
                    <div class="article-title">
                        <h6><a href="#">Lifestyle</a></h6>
                        <h2>They Now Bade Farewell To The Kind But Unseen People</h2>
                        <div class="media">
                            <div class="avatar">
                                <img src="https://bootdey.com/img/Content/avatar/avatar1.png" title="" alt="">
                            </div>
                            <div class="media-body">
                                <label>Rachel Roth</label>
                                <span>26 FEB 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="article-content">
                        <p>Aenean eleifend ante maecenas pulvinar montes lorem et pede dis dolor pretium donec dictum. Vici consequat justo enim. Venenatis eget adipiscing luctus lorem. Adipiscing veni amet luctus enim sem libero tellus viverra venenatis aliquam. Commodo natoque quam pulvinar elit.</p>
                        <p>Eget aenean tellus venenatis. Donec odio tempus. Felis arcu pretium metus nullam quam aenean sociis quis sem neque vici libero. Venenatis nullam fringilla pretium magnis aliquam nunc vulputate integer augue ultricies cras. Eget viverra feugiat cras ut. Sit natoque montes tempus ligula eget vitae pede rhoncus maecenas consectetuer commodo condimentum aenean.</p>
                        <h4>What are my payment options?</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        <blockquote>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                            <p class="blockquote-footer">Someone famous in <cite title="Source Title">Dick Grayson</cite></p>
                        </blockquote>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    </div>
                    <div class="nav tag-cloud">
                        <a href="#">Design</a>
                        <a href="#">Development</a>
                        <a href="#">Travel</a>
                        <a href="#">Web Design</a>
                        <a href="#">Marketing</a>
                        <a href="#">Research</a>
                        <a href="#">Managment</a>
                    </div>
                </article>
                <div class="contact-form article-comment">
                    <h4>Leave a Reply</h4>
                    <form id="contact-form" method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input name="Name" id="name" placeholder="Name *" class="form-control" type="text">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input name="Email" id="email" placeholder="Email *" class="form-control" type="email">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <textarea name="message" id="message" placeholder="Your message *" rows="4" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="send">
                                    <button class="px-btn theme"><span>Submit</span> <i class="arrow"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-4 m-15px-tb blog-aside">
                <!-- Author -->
                <div class="widget widget-author">
                    <div class="widget-title">
                        <h3>Author</h3>
                    </div>
                    <div class="widget-body">
                        <div class="media align-items-center">
                            <div class="avatar">
                                <img src="https://bootdey.com/img/Content/avatar/avatar6.png" title="" alt="">
                            </div>
                            <div class="media-body">
                                <h6>Hello, I'm<br> Rachel Roth</h6>
                            </div>
                        </div>
                        <p>I design and develop services for customers of all sizes, specializing in creating stylish, modern websites, web services and online stores</p>
                    </div>
                </div>
                <!-- End Author -->
                <!-- Trending Post -->
                <div class="widget widget-post">
                    <div class="widget-title">
                        <h3>Trending Now</h3>
                    </div>
                    <div class="widget-body">

                    </div>
                </div>
                <!-- End Trending Post -->
                <!-- Latest Post -->
                <div class="widget widget-latest-post">
                    <div class="widget-title">
                        <h3>Latest Post</h3>
                    </div>
                    <div class="widget-body">
                        <div class="latest-post-aside media">
                            <div class="lpa-left media-body">
                                <div class="lpa-title">
                                    <h5><a href="#">Prevent 75% of visitors from google analytics</a></h5>
                                </div>
                                <div class="lpa-meta">
                                    <a class="name" href="#">
                                        Rachel Roth
                                    </a>
                                    <a class="date" href="#">
                                        26 FEB 2020
                                    </a>
                                </div>
                            </div>
                            <div class="lpa-right">
                                <a href="#">
                                    <img src="https://via.placeholder.com/400x200/FFB6C1/000000" title="" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="latest-post-aside media">
                            <div class="lpa-left media-body">
                                <div class="lpa-title">
                                    <h5><a href="#">Prevent 75% of visitors from google analytics</a></h5>
                                </div>
                                <div class="lpa-meta">
                                    <a class="name" href="#">
                                        Rachel Roth
                                    </a>
                                    <a class="date" href="#">
                                        26 FEB 2020
                                    </a>
                                </div>
                            </div>
                            <div class="lpa-right">
                                <a href="#">
                                    <img src="https://via.placeholder.com/400x200/FFB6C1/000000" title="" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="latest-post-aside media">
                            <div class="lpa-left media-body">
                                <div class="lpa-title">
                                    <h5><a href="#">Prevent 75% of visitors from google analytics</a></h5>
                                </div>
                                <div class="lpa-meta">
                                    <a class="name" href="#">
                                        Rachel Roth
                                    </a>
                                    <a class="date" href="#">
                                        26 FEB 2020
                                    </a>
                                </div>
                            </div>
                            <div class="lpa-right">
                                <a href="#">
                                    <img src="https://via.placeholder.com/400x200/FFB6C1/000000" title="" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Latest Post -->
                <!-- widget Tags -->
                <div class="widget widget-tags">
                    <div class="widget-title">
                        <h3>Latest Tags</h3>
                    </div>
                    <div class="widget-body">
                        <div class="nav tag-cloud">
                            <a href="#">Design</a>
                            <a href="#">Development</a>
                            <a href="#">Travel</a>
                            <a href="#">Web Design</a>
                            <a href="#">Marketing</a>
                            <a href="#">Research</a>
                            <a href="#">Managment</a>
                        </div>
                    </div>
                </div>
                <!-- End widget Tags -->
            </div>
        </div>
    </div>
</div>




<footer class="deneb_footer">
  <div class="widget_wrapper shadow-sm" style="background-color: #fff;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-12">
          <div class="widget widegt_about">
            <div class="widget_title">
              <img src="assets/images/logo_1.png" class="img-fluid" alt="">
          </div>
          <div class="mb-3">
              <div class="btn btn-primary">SIgn Up</div>
              <div class="btn btn-warning">Sign In</div>
          </div>

          <p>Kami sangat terbuka untuk kemitraan untuk semua perusahaan tambang yang memenuhi persyaratan kami. Jika anda tertarik untuk menjual kapasitas hosting untuk pertambangan melalui platform Goldgainer.com, <br/><a href="">silahkan hubungi kami.</a></p>

          <ul class="social mt-3">
              <li><a href="#"><i class="fab fa-facebook-f" style="margin-top: 7px;"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter" style="margin-top: 7px;"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram" style="margin-top: 7px;"></i></a></li>
          </ul>
      </div>
  </div>
  <div class="col-lg-4 col-md-6 col-sm-12">
      <div class="widget widget_link">
        <div class="widget_title">
          <h4>Links</h4>
      </div>
      <ul>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Portfolio</a></li>
          <li><a href="#">Blog</a></li>
      </ul>
  </div>
</div>
<div class="col-lg-4 col-md-6 col-sm-12">
  <div class="widget widget_contact">
    <div class="widget_title">
      <h4>Contact Us</h4>
  </div>
  <div class="contact_info">
      <div class="single_info">
        <div class="icon">
          <i class="fas fa-phone" style="margin-top: 8px;"></i>
      </div>
      <div class="info">
          <p><a href="tel:+919246147999">1800-121-3637</a></p>
          <p><a href="tel:+919246147999">+91 924-614-7999</a></p>
      </div>
  </div>
  <div class="single_info">
    <div class="icon">
      <i class="fas fa-envelope" style="margin-top: 8px;"></i>
  </div>
  <div class="info">
      <p><a href="mailto:info@deneb.com">info@deneb.com</a></p>
      <p><a href="mailto:services@deneb.com">services@deneb.com</a></p>
  </div>
</div>
<div class="single_info">
    <div class="icon">
      <i class="fas fa-map-marker-alt" style="margin-top: 8px;"></i>
  </div>
  <div class="info">
      <p>125, Park street aven, Brocklyn,<span>Newyork.</span></p>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="copyright_area">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="copyright_text">
            <p>Copyright &copy; 2021 All rights reserved.</p>
        </div>
    </div>
</div>
</div>
</div>
</footer>



</body>
</html>
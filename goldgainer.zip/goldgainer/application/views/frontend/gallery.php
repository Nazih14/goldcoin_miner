<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Web Company Profile">
  <meta name="author" content="Muhammad Nazih, S.Kom">

  <title> Goldgainer | PT International Development </title>
  <link rel="icon" href="<?php echo base_url();?>media/images/ico/logo.png" type="icon">
  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url();?>media/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-css">
  <!-- Icons And Animation -->
  <link href="<?php echo base_url();?>media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>media/css/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/css/all.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/brands.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/solid.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/ti-icons@0.1.2/css/themify-icons.css" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link href="<?php echo base_url();?>media/css/custom.css" rel="stylesheet" type="text/css">
  
  
  <!-- Core JavaScript Files -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery-3.2.1.slim.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/all.js"></script>
  <!-- Core JavaScript Plugin -->
  <script src="<?php echo base_url();?>media/js/owl.carousel.js"></script>
  <!-- Custom Theme JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/wow.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/custom.js"></script>
  

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed|Fugaz+One&display=swap|Roboto" rel="stylesheet">

  <script type="text/javascript">
            // $('.portfolio-item').isotope({
        //    itemSelector: '.item',
        //    layoutMode: 'fitRows'
        //  });
        $('.portfolio-menu ul li').click(function(){
          $('.portfolio-menu ul li').removeClass('active');
          $(this).addClass('active');
          
          var selector = $(this).attr('data-filter');
          $('.portfolio-item').isotope({
            filter:selector
          });
          return  false;
        });
        $(document).ready(function() {
         var popup_btn = $('.popup-btn');
         popup_btn.magnificPopup({
           type : 'image',
           gallery : {
            enabled : true
          }
        });
       });
     </script>

   </head>
   <body>  

    <nav class="navbar top-nav fixed-top navbar-expand-lg navbar-white bg-white shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="index.html">Goldgainer.com</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"><img src="https://img.icons8.com/color/48/000000/xbox-menu.png"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav m-auto text-sm-center text-md-center">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url().'page/about';?>">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url().'page/gallery';?>">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url().'page/event';?>">Event</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url().'page/faq';?>">FAQ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url().'page/login';?>"><i class="fas fa-lock"></i> Login</a>
          </li>
        </ul>
      </div>
      <ul class="navbar-nav ml-auto search-box">
        <li class="nav-item d-none d-sm-block">
          <a class="nav-link" href="#"><i class="fab fa-facebook text-white"></i></a>
        </li>
        <li class="nav-item d-none d-sm-block">
          <a class="nav-link" href="#"><i class="fab fa-instagram text-white"></i></a>
        </li>
        <li class="nav-item d-none d-sm-block">
          <a class="nav-link" href="#"><i class="fab fa-youtube text-white"></i></a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- <section id="home" class="intro intro-bg bg-overlay parallax"> -->
    <br><br>
    <section class="deneb_cta mt-5">
      <div class="container">
        <div class="cta_wrapper">
          <div class="row align-items-center">
            <div class="col-lg-7">
              <div class="cta_content">
                <h3>Goldgainer dibentuk oleh para profesional bagi para individu yang ingin terlibat dalam penambangan uang kripto</h3>
                <p>Kami percaya bahwa setiap orang harus mendapatkan keuntungan dari pertambangan dan dapat memiliki akses teknologi terbaru dan pusat data industri skala besar dari laptop atau ponsel.</p>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="button_box">
                <a href="#" class="btn btn-warning">Bergabunglah Bersama kami <span class="fas fa-arrow-right"></span></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="container">
     <div class="row">
      <div class="col-lg-12 text-center my-2 mt-5">
       <h4>Gallery Goldgainer</h4>
     </div>
   </div>

   <div class="portfolio-item row mb-5">
    <div class="item selfie col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/stylish-young-woman-with-bags-taking-selfie_23-2147962203.jpg" class="fancylight popup-btn" data-fancybox-group="light"> 
       <img class="img-fluid" src="https://image.freepik.com/free-photo/stylish-young-woman-with-bags-taking-selfie_23-2147962203.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/pretty-girl-near-car_1157-16962.jpg" class="fancylight popup-btn" data-fancybox-group="light"> 
       <img class="img-fluid" src="https://image.freepik.com/free-photo/pretty-girl-near-car_1157-16962.jpg" alt="">
     </a>
   </div>
   <div class="item selfie col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/blonde-tourist-taking-selfie_23-2147978899.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/blonde-tourist-taking-selfie_23-2147978899.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/cute-girls-oin-studio_1157-18211.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/cute-girls-oin-studio_1157-18211.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/stylish-pin-up-girls_1157-18451.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/stylish-pin-up-girls_1157-18451.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/stylish-pin-up-girl_1157-18940.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/stylish-pin-up-girl_1157-18940.jpg" alt="">
     </a>
   </div>
   <div class="item lap col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/digital-laptop-working-global-business-concept_53876-23438.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/digital-laptop-working-global-business-concept_53876-23438.jpg" alt="">
     </a>
   </div>
   <div class="item lap col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-psd/set-digital-devices-screen-mockup_53876-76507.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-psd/set-digital-devices-screen-mockup_53876-76507.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/young-brunette-woman-with-sunglasses-urban-background_1139-893.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/young-brunette-woman-with-sunglasses-urban-background_1139-893.jpg" alt="">
     </a>
   </div>
   <div class="item lap col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-psd/laptop-digital-device-screen-mockup_53876-76509.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-psd/laptop-digital-device-screen-mockup_53876-76509.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/young-woman-holding-pen-hand-thinking-while-writing-notebook_23-2148029424.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/young-woman-holding-pen-hand-thinking-while-writing-notebook_23-2148029424.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-psd/female-fashion-concept_23-2147643598.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-psd/female-fashion-concept_23-2147643598.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/girl-city_1157-16454.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/girl-city_1157-16454.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/elegant-lady-with-laptop_1157-16643.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/elegant-lady-with-laptop_1157-16643.jpg" alt="">
     </a>
   </div>
   <div class="item lap col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-psd/laptop-mock-up-lateral-view_1310-199.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-psd/laptop-mock-up-lateral-view_1310-199.jpg" alt="">
     </a>
   </div>
   <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
     <a href="https://image.freepik.com/free-photo/portrait-young-woman_1303-10071.jpg" class="fancylight popup-btn" data-fancybox-group="light">
       <img class="img-fluid" src="https://image.freepik.com/free-photo/portrait-young-woman_1303-10071.jpg" alt="">
     </a>
   </div>




 </div>
</div>









<footer class="deneb_footer">
  <div class="widget_wrapper shadow-sm" style="background-color: #fff;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-12">
         <div class="widget widegt_about">
          <div class="widget_title">
            <img src="assets/images/logo_1.png" class="img-fluid" alt="">
          </div>
          <div class="mb-3">
            <div class="btn btn-primary">SIgn Up</div>
            <div class="btn btn-warning">Sign In</div>
          </div>

          <p>Kami sangat terbuka untuk kemitraan untuk semua perusahaan tambang yang memenuhi persyaratan kami. Jika anda tertarik untuk menjual kapasitas hosting untuk pertambangan melalui platform Goldgainer.com, <br/><a href="">silahkan hubungi kami.</a></p>

          <ul class="social mt-3">
            <li><a href="#"><i class="fab fa-facebook-f" style="margin-top: 7px;"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter" style="margin-top: 7px;"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram" style="margin-top: 7px;"></i></a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="widget widget_link">
          <div class="widget_title">
            <h4>Links</h4>
          </div>
          <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Portfolio</a></li>
            <li><a href="#">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="widget widget_contact">
          <div class="widget_title">
            <h4>Contact Us</h4>
          </div>
          <div class="contact_info">
            <div class="single_info">
              <div class="icon">
                <i class="fas fa-phone" style="margin-top: 8px;"></i>
              </div>
              <div class="info">
                <p><a href="tel:+919246147999">1800-121-3637</a></p>
                <p><a href="tel:+919246147999">+91 924-614-7999</a></p>
              </div>
            </div>
            <div class="single_info">
              <div class="icon">
                <i class="fas fa-envelope" style="margin-top: 8px;"></i>
              </div>
              <div class="info">
                <p><a href="mailto:info@deneb.com">info@deneb.com</a></p>
                <p><a href="mailto:services@deneb.com">services@deneb.com</a></p>
              </div>
            </div>
            <div class="single_info">
              <div class="icon">
                <i class="fas fa-map-marker-alt" style="margin-top: 8px;"></i>
              </div>
              <div class="info">
                <p>125, Park street aven, Brocklyn,<span>Newyork.</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="copyright_area">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="copyright_text">
          <p>Copyright &copy; 2021 All rights reserved.</p>
        </div>
      </div>
    </div>
  </div>
</div>
</footer>


</body>
</html>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Web Company Profile">
  <meta name="author" content="Muhammad Nazih, S.Kom">

  <title> Goldgainer | PT International Development </title>
  <link rel="icon" href="<?php echo base_url();?>media/images/ico/logo.png" type="icon">
  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url();?>media/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-css">
  <!-- Icons And Animation -->
  <link href="<?php echo base_url();?>media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>media/css/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/css/all.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/brands.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/solid.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/ti-icons@0.1.2/css/themify-icons.css" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link href="<?php echo base_url();?>media/css/custom.css" rel="stylesheet" type="text/css">
  
  
  <!-- Core JavaScript Files -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery-3.2.1.slim.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/all.js"></script>
  <!-- Core JavaScript Plugin -->
  <script src="<?php echo base_url();?>media/js/owl.carousel.js"></script>
  <!-- Custom Theme JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/wow.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/custom.js"></script>
  
  <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed|Fugaz+One&display=swap|Roboto" rel="stylesheet">
  
</head>
<body>  

  <nav class="navbar top-nav fixed-top navbar-expand-lg navbar-white bg-white shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="index.html">Goldgainer.com</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"><img src="https://img.icons8.com/color/48/000000/xbox-menu.png"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav m-auto text-sm-center text-md-center">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/about';?>">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/gallery';?>">Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/event';?>">Event</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/faq';?>">FAQ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/login';?>"><i class="fas fa-lock"></i> Login</a>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav ml-auto search-box">
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-facebook text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-instagram text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-youtube text-white"></i></a>
      </li>
    </ul>
  </div>
</nav>


	<br><br>
	<div class="container h-100 mt-5 mb-5">
		<div class="row h-100">
			<div class="col-sm-10 col-md-8 col-lg-4 mx-auto d-table h-100">
				<div class="d-table-cell align-middle">

					<div class="text-center mt-4">
						<h1 class="h2">Welcome back, Dey</h1>
						<p class="lead">
							Sign in to your account to continue
						</p>
					</div>

					<div class="card">
						<div class="card-body">
							<div class="m-sm-4">
								<div class="text-center">
									<img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="Andrew Jones" class="img-fluid rounded-circle" width="112" height="112">
								</div>
								<form>
									<div class="form-group">
										<label>Email</label>
										<input class="form-control form-control-md" type="email" name="email" placeholder="Enter your email">
									</div>
									<div class="form-group">
										<label>Password</label>
										<input class="form-control form-control-md" type="password" name="password" placeholder="Enter your password">
										<small>
											<a href="pages-reset-password.html">Forgot password?</a>
										</small>
									</div>
									<div>
										<div class="custom-control custom-checkbox align-items-center">
											<input type="checkbox" class="custom-control-input" value="remember-me" name="remember-me" checked="">
											<label class="custom-control-label text-small">Remember me next time</label>
										</div>
									</div>
									<div class="text-center mt-3">
										<a href="index.html" class="btn btn-md btn-primary">Sign in</a>
										<!-- <button type="submit" class="btn btn-lg btn-primary">Sign in</button> -->
									</div>
								</form>
							</div>
						</div>
					</div>
					<br>
					<center>
						<a href="index.html"><p><i class="fas fa-home"></i>  Beranda</p></a>
					</center>
				</div>
			</div>
		</div>
	</div>





</body>
</html>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Web Company Profile">
  <meta name="author" content="Muhammad Nazih, S.Kom">

  <title> Goldgainer | PT International Development </title>
  <link rel="icon" href="<?php echo base_url();?>media/images/ico/logo.png" type="icon">
  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url();?>media/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-css">
  <!-- Icons And Animation -->
  <link href="<?php echo base_url();?>media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>media/css/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/css/all.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/brands.css" rel="stylesheet">
  <link href="<?php echo base_url();?>media/fonts/font-awesome-master/css/solid.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/ti-icons@0.1.2/css/themify-icons.css" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link href="<?php echo base_url();?>media/css/custom.css" rel="stylesheet" type="text/css">
  
  
  <!-- Core JavaScript Files -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery-3.2.1.slim.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/all.js"></script>
  <!-- Core JavaScript Plugin -->
  <script src="<?php echo base_url();?>media/js/owl.carousel.js"></script>
  <!-- Custom Theme JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/wow.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/custom.js"></script>
  
  <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed|Fugaz+One&display=swap|Roboto" rel="stylesheet">
  
</head>
<body>  

  <nav class="navbar top-nav fixed-top navbar-expand-lg navbar-white bg-white shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="index.html">Goldgainer.com</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"><img src="https://img.icons8.com/color/48/000000/xbox-menu.png"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <ul class="navbar-nav m-auto text-sm-center text-md-center">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/about';?>">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/gallery';?>">Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/event';?>">Event</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/faq';?>">FAQ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url().'page/login';?>"><i class="fas fa-lock"></i> Login</a>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav ml-auto search-box">
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-facebook text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-instagram text-white"></i></a>
      </li>
      <li class="nav-item d-none d-sm-block">
        <a class="nav-link" href="#"><i class="fab fa-youtube text-white"></i></a>
      </li>
    </ul>
  </div>
</nav>





<!-- Row -->
<section>
    <div class="mt-5 mb-5">
        <div class="pa-0">
            <div class="faq-search-wrap bg-teal-light-3">
                <div class="container">
                    <div class="row">
                        <h1 class="display-5 text-white mb-20">Ask a question or browse by category below.</h1>
                        <div class="form-group w-100 mb-0">
                            <div class="input-group">
                                <input class="form-control form-control-lg filled-input bg-white" placeholder="Search by keywords" type="text">
                                <div class="input-group-append">
                                    <span class="input-group-text"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container mt-sm-60 mt-30">
                <div class="hk-row">
                    <div class="col-xl-4">
                        <div class="card">
                            <h6 class="card-header">
                                Category
                            </h6>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex align-items-center active">
                                    <i class="ion ion-md-sunny mr-15"></i>Terms &amp; conditions<span class="badge badge-light badge-pill ml-15">06</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center">
                                    <i class="ion ion-md-unlock mr-15"></i>Privacy policy<span class="badge badge-light badge-pill ml-15">14</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center">
                                    <i class="ion ion-md-bookmark mr-15"></i>Terms of use<span class="badge badge-light badge-pill ml-15">10</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center">
                                    <i class="ion ion-md-filing mr-15"></i>Documentation<span class="badge badge-light badge-pill ml-15">27</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-8">
                        <div class="card card-lg">
                            <h3 class="card-header border-bottom-0">
                                Terms and Conditions
                            </h3>
                            <div class="accordion accordion-type-2 accordion-flush" id="accordion_2">
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between activestate">
                                        <a role="button" data-toggle="collapse" href="#collapse_1i" aria-expanded="true">The Intellectual Property</a>
                                    </div>
                                    <div id="collapse_1i" class="collapse show" data-parent="#accordion_2" role="tabpanel">
                                        <div class="card-body pa-15">The Intellectual Property disclosure will inform users that the contents, logo and other visual media you created is your property and is protected by copyright laws.</div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between">
                                        <a class="collapsed" role="button" data-toggle="collapse" href="#collapse_2i" aria-expanded="false">Termination clause</a>
                                    </div>
                                    <div id="collapse_2i" class="collapse" data-parent="#accordion_2">
                                        <div class="card-body pa-15">A Termination clause will inform that users’ accounts on your website and mobile app or users’ access to your website and mobile (if users can’t have an account with you) can be terminated in case of abuses or at your sole discretion.</div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between">
                                        <a class="collapsed" role="button" data-toggle="collapse" href="#collapse_3i" aria-expanded="false">Governing Law</a>
                                    </div>
                                    <div id="collapse_3i" class="collapse" data-parent="#accordion_2">
                                        <div class="card-body pa-15">A Governing Law will inform users which laws govern the agreement. This should the country in which your company is headquartered or the country from which you operate your website and mobile app.</div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between">
                                        <a class="collapsed" role="button" data-toggle="collapse" href="#collapse_4i" aria-expanded="false">Limit what users can do</a>
                                    </div>
                                    <div id="collapse_4i" class="collapse" data-parent="#accordion_2">
                                        <div class="card-body pa-15">A Limit What Users Can Do clause can inform users that by agreeing to use your service, they’re also agreeing to not do certain things. This can be part of a very long and thorough list in your Terms and Conditions agreements so as to encompass the most amount of negative uses.</div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between">
                                        <a class="collapsed" role="button" data-toggle="collapse" href="#collapse_5i" aria-expanded="false">Limitation of liability of your products</a>
                                    </div>
                                    <div id="collapse_5i" class="collapse" data-parent="#accordion_2">
                                        <div class="card-body pa-15">No matter what kind of goods you sell, best practices direct you to present any warranties you are disclaiming and liabilities you are limiting in a way that your customers will notice.</div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between">
                                        <a class="collapsed" role="button" data-toggle="collapse" href="#collapse_6i" aria-expanded="false">How to enforce Terms and Conditions</a>
                                    </div>
                                    <div id="collapse_6i" class="collapse" data-parent="#accordion_2">
                                        <div class="card-body pa-15">While creating and having a Terms and Conditions is important, it’s far more important to understand how you can make the Terms and Conditions enforceable. You should always use clickwrap to get users to agree to your Terms and Conditions. Clickwrap is when you make your users take some action – typically clicking something – to show they’re agreeing. Here’s how Engine Yard uses the clickwrap agreement with the I agree check box:</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Row -->








<footer class="deneb_footer">
  <div class="widget_wrapper shadow-sm" style="background-color: #fff;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-12">
         <div class="widget widegt_about">
            <div class="widget_title">
              <img src="assets/images/logo_1.png" class="img-fluid" alt="">
          </div>
          <div class="mb-3">
              <div class="btn btn-primary">SIgn Up</div>
              <div class="btn btn-warning">Sign In</div>
          </div>

          <p>Kami sangat terbuka untuk kemitraan untuk semua perusahaan tambang yang memenuhi persyaratan kami. Jika anda tertarik untuk menjual kapasitas hosting untuk pertambangan melalui platform Goldgainer.com, <br/><a href="">silahkan hubungi kami.</a></p>

          <ul class="social mt-3">
              <li><a href="#"><i class="fab fa-facebook-f" style="margin-top: 7px;"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter" style="margin-top: 7px;"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram" style="margin-top: 7px;"></i></a></li>
          </ul>
      </div>
  </div>
  <div class="col-lg-4 col-md-6 col-sm-12">
      <div class="widget widget_link">
        <div class="widget_title">
          <h4>Links</h4>
      </div>
      <ul>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Portfolio</a></li>
          <li><a href="#">Blog</a></li>
      </ul>
  </div>
</div>
<div class="col-lg-4 col-md-6 col-sm-12">
  <div class="widget widget_contact">
    <div class="widget_title">
      <h4>Contact Us</h4>
  </div>
  <div class="contact_info">
      <div class="single_info">
        <div class="icon">
          <i class="fas fa-phone" style="margin-top: 8px;"></i>
      </div>
      <div class="info">
          <p><a href="tel:+919246147999">1800-121-3637</a></p>
          <p><a href="tel:+919246147999">+91 924-614-7999</a></p>
      </div>
  </div>
  <div class="single_info">
    <div class="icon">
      <i class="fas fa-envelope" style="margin-top: 8px;"></i>
  </div>
  <div class="info">
      <p><a href="mailto:info@deneb.com">info@deneb.com</a></p>
      <p><a href="mailto:services@deneb.com">services@deneb.com</a></p>
  </div>
</div>
<div class="single_info">
    <div class="icon">
      <i class="fas fa-map-marker-alt" style="margin-top: 8px;"></i>
  </div>
  <div class="info">
      <p>125, Park street aven, Brocklyn,<span>Newyork.</span></p>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="copyright_area">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="copyright_text">
            <p>Copyright &copy; 2021 All rights reserved.</p>
        </div>
    </div>
</div>
</div>
</div>
</footer>


</body>
</html>


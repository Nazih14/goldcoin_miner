<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta id="Viewport" name="viewport" content="initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
  <meta name="description" content="ICCTP">
  <meta name="author" content="blackbops">
  
  <title>ICCTP</title>
  <link rel="icon" href="<?php echo base_url();?>media/images/icon/logob.png" type="icon">
  <!-- Bootstrap Core CSS -->
  <link href="<?php echo base_url();?>media/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-css">
  <!-- Icons -->
  <link href="<?php echo base_url();?>media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>media/css/all.css" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link href="<?php echo base_url();?>media/css/custom.css" rel="stylesheet" type="text/css">
  
  <!-- Core JavaScript Files -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/jquery-3.2.1.slim.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/all.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
  <!-- Custom Theme JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>media/js/wow.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>media/js/custom.js"></script>
  
  <link href="https://fonts.googleapis.com/css?family=Patua+One|Roboto+Condensed|Roboto|Oswald&display=swap" rel="stylesheet">

</head>
<body> 

  <header> 
    <nav class="navbar fixed-top top-nav navbar-expand-lg navbar-white bg-white shadow-sm">
      <div class="container-fluid">
        <a class="navbar-brand text-dark" href="#"><img src="<?php echo base_url();?>media/images/icon/logoic.png" alt="" width="50%"> </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
          <ul class="navbar-nav">
            <li class="nav-item"> <a class="nav-link" href="#about">About Us</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#service">Gallery</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#visi">Event</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#portfolio">FAQ</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#portfolio">Member Area</a> </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <section class="boot-elemant-bg1 py-md-5 py-5" id="about">
    <div class="container position-relative py-md-5 py-0">
      <div class="row justify-content-center">
        <div class="col-lg-9 mt-5 mb-5">
          <br><br>
          <span class="text-uppercase">Technology</span>
          <h2 class="display-3 color-h2 text-center text-uppercase">welcome to blockchain council </h2>
          <p class="f-16 mb-4 text-center">The Blockchain Council is an authoritative group of experts and enthusiasts who are evangelizing the Blockchain Research, Development, Use Cases, Products and Knowledge for the better world.
          </p>
          <center>
            <!-- <a href="#" class="btn btn-outline-primary btn-lg px-4"> Read More </a> -->
          </center>

          <section class="customer-logos slider mt-5">
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/1.png"></div>
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/2.png"></div>
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/3.png"></div>
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/4.png"></div>
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/5.png"></div>
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/6.png"></div>
            <div class="slide"><img src="<?php echo base_url();?>media/images/support/7.png"></div>
          </section>

        </div>
      </div>
    </div>
  </section> 


  <section class="section services-section" id="services">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="section-title">
            <h2>Why must you join?</h2>
            <p>I design and develop services for customers of all sizes, specializing in creating stylish, modern websites</p>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- feaure box -->
        <div class="col-sm-6 col-lg-4">
          <div class="feature-box-1">
            <div class="icon">
              <i class="fas fa-desktop mt-4"></i>
            </div>
            <div class="feature-content">
              <h5>Learn & Qualify</h5>
              <p>Learn about the key areas and implementation of the blockchain technology to distinguish your professional profile, and get certified by the blockchain council.</p>
            </div>
          </div>
        </div>
        <!-- / -->
        <!-- feaure box -->
        <div class="col-sm-6 col-lg-4">
          <div class="feature-box-1">
            <div class="icon">
              <i class="fas fa-user mt-4"></i>
            </div>
            <div class="feature-content">
              <h5>Develop & Build</h5>
              <p>Develop and build up your career in the Blockchain technology space, and explore more about Blockchain with our Blockchain council members who expertise in this technology</p>
            </div>
          </div>
        </div>
        <!-- / -->
        <!-- feaure box -->
        <div class="col-sm-6 col-lg-4">
          <div class="feature-box-1">
            <div class="icon">
              <i class="fas fa-comment mt-4"></i>
            </div>
            <div class="feature-content">
              <h5>Lead & Grow</h5>
              <p>Lead & grow the world by providing Blockchain based solutions to businesses and enterprise applications</p>
            </div>
          </div>
        </div>
        <!-- / -->

      </div>
    </div>
  </section>


  <section class="boot-elemant-bg3 py-md-5 py-4 shadow-lg">
    <div class="container position-relative py-md-5 py-0 mb-5">
      <div class="row justify-content-center mt-5">
        <div class="col-md-6 col-sm-12">

        </div>
        <div class="col-md-6 col-sm-12">
          <div class="inner mb-5">
            <h2 class="display-4 color-h2 text-uppercase mb-4">About Us</h2>
            <p class="para1">Blockchain Council is an authoritative group of subject experts and enthusiasts who are evangelizing the Blockchain Research and Development, Use Cases and Products and Knowledge for the better world. Blockchain council creates an environment and raises awareness among businesses, enterprises, developers, and society by educating them in the Blockchain space. We are a private de-facto organization working individually and proliferating Blockchain technology globally. 
            </p>
            
            <br/>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section class="boot-elemant-bg4 py-md-5 py-4 pt-5">
    <div class="container position-relative py-md-5 py-0 mt-5">
      <div class="row justify-content-center mt-5">
        <div class="col-md-6 col-sm-12">
         <div class="inner mb-5">
          <h2 class="display-4 color-h2 text-uppercase mb-5">Blockchain Certifications</h2>
          <p>Get certified and enhance your skills in the Blockchain technology space</p>

          <h5 class="font-weight-bold">Get hired easily</h5>
          <!-- <p class="para1">Memberikan layanan yang unggul dan cepat untuk pelanggan khusus</p> -->
          <hr>
          <h5 class="font-weight-bold">In-depth understanding of Blockchain</h5>
          <hr>
          <h5 class="font-weight-bold">Implementing Blockchain on business applications</h5>
          <hr>
          <h5 class="font-weight-bold">Blockchain and its use cases</h5>
          <hr>
          <h5 class="font-weight-bold">Lifetime access to the training videos</h5>
          <hr>
          <h5 class="font-weight-bold">Certified individuals name will be published on the website</h5>
          <hr>
          <h5 class="font-weight-bold">Assistance will be provided throughout the training program</h5>
          <hr>
        </div>
      </div>
      <div class="col-md-6 col-sm-12">
      </div>
    </div>
  </div>
</section>

<section class="boot-elemant-bg6 py-md-5 py-4 pt-5" id="portfolio" >
  <!-- PORTFOLIO -->
  <div class="content-section pb-5">
    <div class="container">
      <div class="row">
       <div class="col-md-12 col-sm-12">
        <h2 class="display-5 color-h2 text-center text-uppercase">CERTIFICATIONS WE PROVIDE </h2>
        <p class="text-center">Partner Your Business</p>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <a href="#" target="_blank">
            <img src="<?php echo base_url();?>media/images/support/block.jpg" alt="Project Dummy">
            <div class="caption">
              <h4>Program Duration - 9 hours</h4>
              <p>A Certified Blockchain Expert™ is a professional who understands Blockchain technology profoundly and can design</p>
            </div>
          </a>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <a href="#" target="_blank">
            <img src="<?php echo base_url();?>media/images/support/block.jpg" alt="Project Dummy">
            <div class="caption">
              <h4>Program Duration - 9 hours</h4>
              <p>A Certified Blockchain Developer is a professional who understands blockchain technology profoundly and can build...</p>
            </div>
          </a>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
         <a href="#" target="_blank">
          <img src="<?php echo base_url();?>media/images/support/block.jpg" alt="Project Dummy">
          <div class="caption">
            <h4>Program Duration - 9 hours</h4>
            <p>Certified Blockchain Architect training and certification enables you to gain expert understanding and exposure of...</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>
</div>
</section>


<section class="boot-elemant-bg5 py-md-5 py-4" id="visi">
  <div class="container position-relative py-md-5 py-0">
    <div class="row">
     <div class="row team-row">
      <div class="col-md-7 col-sm-12 team-wrap">
        <div class="team-member text-center">
          <div class="team-img">
            <img src="<?php echo base_url();?>media/images/icon/logob.png" alt="" width="100%">
            <div class="overlay-team">
              <div class="team-details text-center">
                <div class="socials mt-20">
                  <a href="#">
                    <i class="fab fa-facebook"></i>
                  </a>
                  <a href="#">
                    <i class="fab fa-twitter"></i>
                  </a>
                  <a href="#">
                    <i class="fab fa-google-plus"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
         <!--  <h6 class="team-title">Mr. Eric Bram</h6>
          <span>CEO</span> -->
        </div>
      </div>
      <!-- end team member -->
      <div class="col-md-5 col-sm-12">
        <div class="inner mt-5">
          <div class="container-fluid">
            <h3 class="main-heading">Our Vision</h3>
            <hr>
            <h5 class="para1">"Menjadi perusahaan yang kreatif dan inovatif untuk mewujudkan kebutuhan pelanggan dan fokus pada pengembangan dan penyediaan layanan IT Software solution“
            </h5>
            <br>
            <h3 class="main-heading">Our Mision</h3>
            <hr>
            <h5 class="para1">“Transformasi untuk melayani lebih baik”</h5>

          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</section>



<footer>
  <div class="copyright">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <span>Copyright © 2021, ICCTP</span>
        </div>
        <!-- End Col -->
        <div class="col-md-6">
          <div class="copyright-menu">
            <ul>
              <li>
                <a href="#">Home</a>
              </li>
              <li>
                <a href="404.html">Karir</a>
              </li>
              <li>
                <a href="404.html">Event</a>
              </li>
            </ul>
          </div>
        </div>
        <!-- End col -->
      </div>
      <!-- End Row -->
    </div>
    <!-- End Copyright Container -->
  </div>
</footer>

<!-- <a href="#" target="_blank" class="bannerbawah" style="display: inline;"><img src="media/images/support/chatwa.png" alt="banner bawah"></a> -->


</body>
</html>

<script type="text/javascript">
  $(document).ready(function(){
    $('.customer-logos').slick({
      slidesToShow: 6,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 1500,
      arrows: false,
      dots: false,
      pauseOnHover: false,
      responsive: [{
        breakpoint: 768,
        settings: {
          slidesToShow: 4
        }
      }, {
        breakpoint: 520,
        settings: {
          slidesToShow: 3
        }
      }]
    });
  });
</script>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

	function __construct(){
		parent::__construct();
		$autoload['helper'] = array('url');
	}

	public function index()
	{
		$data['judul'] = "Halaman Home";
		$this->load->view('frontend/index');
	}

	public function about(){		
		$data['judul'] = "Halaman about";
		$this->load->view('frontend/about');
	}

	public function gallery(){		
		$data['judul'] = "Halaman gallery";
		$this->load->view('frontend/gallery');
	}

	public function event(){		
		$data['judul'] = "Halaman event";
		$this->load->view('frontend/event');
	}

	public function faq(){		
		$data['judul'] = "Halaman faq";
		$this->load->view('frontend/faq');
	}

	public function detail(){		
		$data['judul'] = "Halaman detail";
		$this->load->view('frontend/detail');
	}

	public function login(){		
		$data['judul'] = "Halaman login";
		$this->load->view('frontend/login');
	}

	public function register(){		
		$data['judul'] = "Halaman register";
		$this->load->view('frontend/register');
	}
}

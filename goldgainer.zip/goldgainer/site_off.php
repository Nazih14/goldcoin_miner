<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Dalam Perbaikan">
  <meta name="author" content="Batikrun Nusantara">

  <title>Dalam Perbaikan</title>
  <!-- Bootstrap Core CSS -->
  <link rel="stylesheet" href="https://colorrun.id/media/css/lumen.min.css">
  <link href="https://colorrun.id/media/css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="https://colorrun.id/media/css/typicons.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Markazi+Text|Roboto" rel="stylesheet">

  <style type="text/css">
  body {
    background: #2c3e50;
    font-family: 'Noto Sans', sans-serif;
    margin: 0;
    color: #fff;
    overflow-x: hidden !important;
    padding-top:40px;
    font-family: 'Roboto', sans-serif;
  }

  .message-box h1 {
    color: #fff;
    font-size: 98px;
    font-weight: 700;
    line-height: 98px;
    margin-top: 90px;
    text-shadow: rgba(61, 61, 61, 0.3) 1px 1px, rgba(61, 61, 61, 0.2) 2px 2px, rgba(61, 61, 61, 0.3) 3px 3px;
  }
</style>


</head>
<body>

    <div class="container">
      <div class="row justify-content-center">

        <div class="col-md-8">
          <div class="message-box border-left pl-5" style="border-left-width: 5px !important;">
            <h1 class="mb-4">We are Leveling Up!</h1>
            <p>Hi, mohon maaf saat ini kami menutup akses kamu ke situs. Saat ini kami sedang melakukan update ke sistem kami untuk kamu. Untuk Informasi lebih lanjut, kamu dapat menghubungi PIC kami melalui nomor <b class="text-danger">0877 7660 8920 Via WhatsApp (Hengki)</b>. Terimakasih atas pengertian anda.</p>
            <p>Dengan Hormat, Admin.</p>
          </div>
        </div>

      </div>
    </div>

</body>
</html>